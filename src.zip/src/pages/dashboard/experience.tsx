'use client';

import dynamic from 'next/dynamic';
import Loader from '~/components/loader';

const ExperiencePage = dynamic(() => import('~/features/dashboard/pages/ExperiencePage'), {
  loading: () => <Loader />,
  ssr: false,
});

export default ExperiencePage;
